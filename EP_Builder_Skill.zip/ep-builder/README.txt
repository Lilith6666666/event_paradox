EP BUILDER
==========

Portable Skill package for Event Paradox v0.4 Public Beta.

Purpose
-------
EP Builder compiles plain-language Event Paradox design into a complete,
validated definitions structure:

- EP_START
- EP_CHAPTERS
- EP_EVENTS

It can also edit, validate and repair existing Event Paradox definitions.

Primary usage
-------------
Attach or open a filled EventParadox_Author_Workbook.txt and say:

Compile this for Event Paradox.

Other examples:

Create the complete EP structure from these event notes.

Add these events to my existing Event Paradox definitions.

Validate this EP file.

Repair this EP file and return the corrected .txt.

Files
-----
SKILL.md
  Main portable Skill instructions.

references/EventParadox_AI_Authoring_Spec.txt
  Authoritative EP Builder authoring contract.

references/EventParadox_v0.4_README.txt
  Current Event Paradox v0.4 technical reference.

references/EventParadox_Events_Creator_v0.4.txt
  Current manual authoring reference.

references/EventParadox_Author_Toolkit_Examples.txt
  Human-to-EP worked examples.

templates/EventParadox_Author_Workbook.txt
  Blank event-first Workbook for human creators.

docs/EventParadox_Skill_Builder_Guide.txt
  Vendor-neutral setup guide for adapting the package to other AI platforms.

Version
-------
EP Builder 1.0
Event Paradox compatibility: v0.4 Public Beta
